# Course Text Mining
This repository contains the material used in the Text Mining course as taught at the Vrije Universiteit Amsterdam.


The folder `lab_sessions` contains one folder for each lab session as well as a folder called `other` with material that could be useful for future editions of the course.

# Installation
Please make sure you do the following in order to run the application.
1. backend: navigate to the backend folder and run `python api.py` file, now you should have the server up and running. 
2. frontend: you have to have nodejs.org at least 16.* (follow [this guide](https://computingforgeeks.com/how-to-install-node-js-on-ubuntu-debian/))  installed on your machine. After installing it, you can navigate to the `frontend` folder and run the following `npm install` . This will install all necessary packages.
3. now you can run the application: `npm start`.
    - if you face CORS problems, you can install an extension that prevents this behavior. We have inlcuded it a preventive package, but it may depend on your OS.
